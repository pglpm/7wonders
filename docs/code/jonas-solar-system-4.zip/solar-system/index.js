/** MIT License / Copyright (c) 2024 Jonas Pytte */

/** @type HTMLDivElement */
const wrapper = document.querySelector(".wrapper")
const planets = wrapper.children
const slider = document.querySelector("input")
/** @type Text */
const result = slider.nextElementSibling.firstChild
const pauseBtn = document.querySelector("button")
const options = document.querySelector(".options")
const scaleLine = document.querySelector(".line")
/** @type Text */
const scaleText = scaleLine.previousElementSibling.firstChild
/** @type Text */
const scaleMagnitude = scaleText.nextSibling.firstChild
const numPlanets = 10

/** Positions of all planets in 10⁹m */
const position = [
  [-0.3486, 0.10374],
  [0, 69.82],
  [-108.21, 0],
  [149.194, 0],
  [149.598, 0],
  [0, -249.3],
  [816.363, 0],
  [-1506.53, 0],
  [0, 3001.39],
  [0, -4558.86],
]

/** Velocities of all planets in 10⁹m/s */
const velocity = [
  [-6.1859e-12, 9.2602142e-9],
  [3.886e-5, 0],
  [0, 3.502e-5],
  [0, -2.8813e-5],
  [0, -2.9783e-5],
  [-2.197e-5, 0],
  [0, -1.244e-5],
  [0, 9.14e-6],
  [6.49e-6, 0],
  [-5.37e-6, 0],
]

/** Masses of all planets in kg */
const masses = [
  1.99e30,    // Sun
  3.3301e23,  // Mercury
  4.8673e24,  // Venus
  7.346e22,   // Moon
  5.9722e24,  // Earth
  6.4169e23,  // Mars
  1.89813e27, // Jupiter
  5.6832e26,  // Saturn
  8.6811e25,  // Uranus
  1.02409e26, // Neptune
]

/** Graviational constant. Scaled since we use 10⁹m as our unit of distance */
const G = 6.67408e-38
const accel = Array(numPlanets * 2 - 2)

/** Sets the view offset equal to the planet's position to focus it */
const focusPlanet = () => {
  posX = -position[focusedPlanet - 1][0] * scale
  posY = position[focusedPlanet - 1][1] * scale
}

/** Updates the position of all planets in the view */
const updatePlanets = () => {
  let planetScale = scale ** -0.8
  for (let i = 0; i < numPlanets; i++) {
    planets[i].style.transform = `translate(${position[i][0] - 25}px, ${-position[i][1] - 25}px) scale(${planetScale})`
  }
}

/** Moves the view to the current offset and updates its scale */
const updateView = () => {
  wrapper.style.transform = `translate(${posX}px, ${posY}px) scale(${scale})`
}

/**
 * The animation loop
 * @param {number} time
 */
const animate = time => {
  if (!paused && prevTime) {
    for (let delta = step * simRate; prevTime < time; prevTime += step) {
      accel.fill(0)
      // Calcuating the acceleration for all planets
      for (let i = 0; i < numPlanets; i++) {
        // Initializing with acceleration from all previous planets
        let accelX = i && accel[2 * i - 2]
        let accelY = i && accel[2 * i - 1]
        // Position of the planet we are calculating the acceleration of
        let [x1, y1] = position[i]
        let mass = masses[i]

        // Calculating the forces between the current planet and all planets further from the Sun
        for (let j = i + 1; j < numPlanets; j++) {
          let [x, y] = position[j]
          let rx = x - x1
          let ry = y - y1
          let r2 = rx ** 2 + ry ** 2
          // Newtons law of gravity
          let a1 = G * masses[j] / r2
          let a2 = G * mass / r2
          let r = r2 ** 0.5
          // Calculating the x and y components of the acceleration
          accelX += a1 * rx / r
          accelY += a1 * ry / r
          // Decrementing the acceleration of the other planet
          accel[2 * j - 2] -= a2 * rx / r
          accel[2 * j - 1] -= a2 * ry / r
        }
        // Try updating the position first if you want the system to diverge quickly
        velocity[i][0] += accelX * delta
        velocity[i][1] += accelY * delta
        position[i][0] += velocity[i][0] * delta
        position[i][1] += velocity[i][1] * delta
      }
    }

    // Updating the view
    if (focusedPlanet) {
      focusPlanet()
      updateView()
    }
    updatePlanets()
  }
  else prevTime = time
  requestAnimationFrame(animate)
}

requestAnimationFrame(animate)

onmousemove = e => {
  if (e.buttons != 1 || focusedPlanet) return
  let moveScale = e.mozPressure == null ? 1 / devicePixelRatio : 1
  // Moving the position if the left mouse button is held
  posX += e.movementX * moveScale
  posY += e.movementY * moveScale
  updateView()
}

/** Scale for the view */
let scale = 1
/** x-component of the view offset */
let posX = 0
/** y-component of the view offset */
let posY = 0
/**
 * Simulation rate in seconds per millisecond.
 * Use the slider instead of changing this
 */
let simRate = 1728
/**
 * Simulation step in milliseconds.
 * This is altered when moving the simulation rate slider
 */
let step = 0.1
/** @type {number} */
let prevTime
let paused = false
let focusedPlanet = 0

onwheel = e => {
  if (e.ctrlKey) return
  const dx = e.deltaX
  const dy = e.deltaY
  const delta = (Math.abs(dy) > Math.abs(dx) ? dy : dx) < 0 ? 1 : -1
  const oldScale = scale

  scale = Math.min(delta / 15 * scale + scale, 1e7)
  if (focusedPlanet) {
    focusPlanet()
  } else {
    // Ensuring the cursor doesn't move after changing the scale
    const pointX = e.pageX - wrapper.offsetLeft
    const pointY = e.pageY - wrapper.offsetTop
    posX = (posX - pointX) * scale / oldScale + pointX
    posY = (posY - pointY) * scale / oldScale + pointY
  }

  const magnitude = 8 - Math.log10(scale / 3)
  const floor = Math.floor(magnitude)
  const rest = magnitude - floor
  const firstDigit = rest < 0.3 ? 1 : rest < 0.7 ? 2 : 5

  scaleText.data = `${firstDigit}×10`
  scaleMagnitude.data = floor
  scaleLine.style.width = firstDigit * 10 ** (floor - 6) * scale + "px"

  updateView()
  updatePlanets()
}

onclick = e => {
  if (e.target.matches("body, .planet")) {
    focusedPlanet = [].indexOf.call(planets, e.target) + 1
    if (focusedPlanet) {
      focusPlanet()
      updateView()
    }
  }
}

updatePlanets()

options.onmousemove = pauseBtn.onmousemove = e => {
  e.stopPropagation()
}

pauseBtn.onclick = () => {
  pauseBtn.textContent = paused ? "Pause" : "Unpause"
  paused = !paused
}

slider.oninput = () => {
  const value = +slider.value
  // Logaritmic slider
  simRate = 2 ** (value / 5) * 6.75
  /* Setting a lower time step for simulation rates over 1000
     days per second and displaying it in years/sec instead. */
  step = value < 69 ? 0.1 : 0.01
  result.data = value < 69
    ? `${(simRate / 3.6 / 24).toFixed(2)} days/sec`
    : `${(simRate * 3.16888e-5).toFixed(2)} years/sec`
}

document.onvisibilitychange = () => {
  if (document.visibilityState == "hidden") pauseBtn.click()
}
